import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

class Game {

    private Main object = new Main();

    private List<String> movieList;

    private String wrongGuesses;
    private int pointsCheck;

    String getWrongGuesses() {
        return wrongGuesses;
    }

    Game(String filename) throws IOException {

        moviesList(filename);
        wrongGuesses = "";
        pointsCheck = 10;

    }

    private void moviesList(String filename) throws IOException {

        // method to accept a filename and read its contents to an ArrayList.

        BufferedReader bufferedReader = new BufferedReader(new FileReader(filename));
        movieList = new ArrayList<>();

        String newLine = bufferedReader.readLine();
        while (newLine != null) {
            movieList.add(newLine);
            newLine = bufferedReader.readLine();
        }
        bufferedReader.close();

    }

    List getMovieList() {
        return movieList;
    }

    String randomMoviePicker(List movieList) {

        return movieList.get(new Random().nextInt(movieList.size())).toString();
    }

    String convertToBlanks() {

        return object.getRandomMovieName().replaceAll("[a-zA-Z]", "~");

    }

    String matchInputToBlanks(String userInput) {

        StringBuilder onMatch = new StringBuilder(object.getBlankMovieName());
        int index = object.getRandomMovieName().indexOf(userInput);

        if (index < 0) {

            wrongGuesses += userInput;
            pointsCheck -= 1;

            System.out.println(userInput + " is not present in movie name. You lose 1 point");
            System.out.println("Points left : " + pointsCheck);

            if (pointsCheck == 0) {
                return "You've lost!";
            }

        } else {

            System.out.println("Your guess is correct!");

            int userGuessLength = userInput.length();

            while (index >= 0) {

                onMatch.setCharAt(index, userInput.charAt(0));
                index = object.getRandomMovieName().indexOf(userInput,
                        index + userGuessLength);

            }
        }

        return onMatch.toString();

    }
}