import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

    private static String randomMovieName;
    private static String blankMovieName;

    public static void main(String[] args) throws IOException {

        try {

            // Creating an object for our Game class and thereby initiating the text file to a list.
            Game game = new Game("moviesList.txt");
            // Picking a random movie from list and storing as a string
            randomMovieName = game.randomMoviePicker(game.getMovieList());
            // String that has equal blanks as that of the movie name.
            blankMovieName = game.convertToBlanks();
            System.out.println("The movie name has " + blankMovieName.length() + " character including spaces : "
                    + blankMovieName);


            do {

                System.out.println("Enter your guess : ");
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
                String guess = bufferedReader.readLine().toLowerCase();

                if (guess.length() > 1) {

                    System.out.println("Please guess a valid letter! Only single alphabets are allowed");
                    System.out.println(blankMovieName);

                } else {

                    if (guess.matches("[^a-z]")) {

                        System.out.println("Enter a valid guess(only letters from a-z allowed). Guess Again!");
                        System.out.println(blankMovieName);

                    } else {

                        if (blankMovieName.contains(guess)) {

                            System.out.println("You have already guessed this letter correct. Guess another!");
                            System.out.println(blankMovieName);

                        } else if (game.getWrongGuesses().contains(guess)) {

                            System.out.println("You lost points guessing this letter. Guess another!");
                            System.out.println(blankMovieName);

                        } else {

                            blankMovieName = game.matchInputToBlanks(guess);
                            System.out.println(blankMovieName);

                        }
                    }
                }
            } while (!blankMovieName.matches(randomMovieName) && !(blankMovieName.equals("You've lost!")));


            if (blankMovieName.matches(randomMovieName)) {
                System.out.println("Congratulations you guessed the movie correctly! Play again!");
            } else {
                System.out.println("Better Luck next time. The movie name was " + randomMovieName);
            }

        } catch (FileNotFoundException e) {
            System.out.println("File not found! Check your file name!");
        }


    }

    String getRandomMovieName() {
        return randomMovieName;
    }

    String getBlankMovieName() {
        return blankMovieName;
    }
}