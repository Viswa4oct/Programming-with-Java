class Item {

    String name;
    int baseWeight;

    Item(String name, int baseWeight) {
        this.name = name;
        this.baseWeight = baseWeight;
    }
}