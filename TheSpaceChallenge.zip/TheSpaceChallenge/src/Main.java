import java.io.FileNotFoundException;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        Simulation simulation = new Simulation();

        // Load Items for Phase-1 and Phase-2
        ArrayList<Item> phase1 = simulation.loadItems("phase-1.txt");
        ArrayList<Item> phase2 = simulation.loadItems("phase-2.txt");

        if(phase1 != null && phase2 != null) {

            // Load U1 rockets for Phase-1, Phase-2
            ArrayList<Rocket> phase1U1 = simulation.loadU1(phase1);
            ArrayList<Rocket> phase2U1 = simulation.loadU1(phase2);

            // Run the simulation on U1 rockets and get the budget
            System.out.println("\nCost of manufacturing U1 rockets = 100 million/rocket\n");

            int phase1U1TotalBudget = simulation.runSimulation(phase1U1);
            System.out.println("\nTotal budget for U1 rockets in phase 1 : " + phase1U1TotalBudget + " million");

            int phase2U1TotalBudget = simulation.runSimulation(phase2U1);
            System.out.println("\nTotal budget for U1 rockets in phase 2 : " + phase2U1TotalBudget + " million");

            System.out.println("\nTotal budget for U1 rockets combined (phase 1 & 2) : " +
                    (phase1U1TotalBudget + phase2U1TotalBudget) + " million\n");

            // Load U2 rockets for Phase-1, Phase-2
            ArrayList<Rocket> phase1U2 = simulation.loadU2(phase1);
            ArrayList<Rocket> phase2U2 = simulation.loadU2(phase2);

            // Run the simulation on U2 rockets and get the budget
            System.out.println("\nCost of manufacturing U2 rockets = 120 million/rocket\n");

            int phase1U2TotalBudget = simulation.runSimulation(phase1U2);
            System.out.println("\nTotal budget for U2 rockets in phase 1 : " + phase1U2TotalBudget + " million");

            int phase2U2TotalBudget = simulation.runSimulation(phase2U2);
            System.out.println("\nTotal budget for U2 rockets in phase 2 : " + phase2U2TotalBudget + " million");

            System.out.println("\nTotal budget for U2 rockets combined (phase 1 & 2) : " +
                    (phase1U2TotalBudget + phase2U2TotalBudget) + " million\n");
        } else {
            System.out.println("Filename not found. Please check the filename and try again");
        }

    }
}