public class U1 extends Rocket {

    private int rocketWeight = 10000;
    private int maxWeightWithCargo = 18000;
    U1() {
        cost = 100;
        maxWeightLimit = maxWeightWithCargo - rocketWeight;
        chanceOfLandingCrash = 0.0;
        chanceOfLaunchExplosion = 0.0;
    }

    @Override
    public boolean launch() {
        this.chanceOfLaunchExplosion = 5.0 * ((double) this.currentWeight / (double) maxWeightLimit);
        System.out.println("Chance of this rocket exploding : " + this.chanceOfLaunchExplosion);
        if(this.chanceOfLaunchExplosion >= randomFunction()) {
            System.out.println("The above rocket has exploded as it has greater chance than random generated no. \n");
            return false;
        } else {
            System.out.println("The above rocket has successfully launched. \n");
            return true;
        }
    }

    @Override
    public boolean land() {
        this.chanceOfLandingCrash = 1.0 * ((double) this.currentWeight / (double) maxWeightLimit);
        System.out.println("Chance of this rocket crashing : " + this.chanceOfLandingCrash);
        if(this.chanceOfLaunchExplosion >= randomFunction()) {
            System.out.println("The above rocket has crashed as it has greater chance than random generated no. \n");
            return false;
        } else {
            System.out.println("The above rocket has successfully landed. \n");
            return true;
        }
    }
}