import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

class Simulation {

    Simulation() {

    }

    ArrayList<Item> loadItems(String fileName) {
        ArrayList<Item> item = new ArrayList<>();
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName));
            String newLine;
            try {
                newLine = bufferedReader.readLine();

                while (newLine != null) {
                    String[] itemValues = newLine.split("=");
                    item.add(new Item(itemValues[0], Integer.parseInt(itemValues[1])));
                    newLine = bufferedReader.readLine();
                }

                bufferedReader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return item;
        } catch (FileNotFoundException e) {
            return null;
        }
    }

    ArrayList<Rocket> loadU1(ArrayList<Item> item) {
        ArrayList<Rocket> rocketList = new ArrayList<>();
        Rocket u1 = new U1();

        for (Item i : item) {
            while (!u1.canCarry(i)) {
                rocketList.add(u1);
                u1 = new U1();
            }

            u1.carry(i);
        }

        rocketList.add(u1);

        return rocketList;
    }

    ArrayList<Rocket> loadU2(ArrayList<Item> item) {
        ArrayList<Rocket> rocketList = new ArrayList<>();
        Rocket u2 = new U2();

        for (Item i : item) {
            while (!u2.canCarry(i)) {
                rocketList.add(u2);
                u2 = new U2();
            }

            u2.carry(i);
        }

        rocketList.add(u2);

        return rocketList;
    }

    int runSimulation(ArrayList<Rocket> rocketList) {
        int numOfCrashes = 0;

        for (Rocket rocket : rocketList) {
            if (!rocket.launch()) {
                rocket.launch();
                numOfCrashes++;
            }
            if (!rocket.land()) {
                rocket.land();
                numOfCrashes++;
            }
        }

        int budget = rocketList.get(0).cost * (rocketList.size() + numOfCrashes);
        System.out.println("\nIn total, " + rocketList.size() + " rockets were a success and " + numOfCrashes +
                " rockets crashed.");

        return budget;
    }
}