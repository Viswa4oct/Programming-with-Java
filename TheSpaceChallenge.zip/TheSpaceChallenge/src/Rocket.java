import java.util.Random;

public class Rocket implements SpaceShip {
    int currentWeight;
    int maxWeightLimit;
    int cost;
    double chanceOfLaunchExplosion;
    double chanceOfLandingCrash;
    private Random random = new Random();

    @Override
    public boolean launch() {
        return true;
    }

    @Override
    public boolean land() {
        return true;
    }

    @Override
    public boolean canCarry(Item item) {
        return this.currentWeight + item.baseWeight <= maxWeightLimit;
    }

    @Override
    public int carry(Item item) {
        this.currentWeight += item.baseWeight;
        return this.currentWeight;
    }

    int randomFunction() {
        int x = (random.nextInt(100));
        System.out.println("The random number generated is : " + x);
        return x;
    }
}